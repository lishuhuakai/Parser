void StoreStartSymbol(char S);
void StoreRule(char lhs, const char *rhs);
void Parse(const char *inp);
